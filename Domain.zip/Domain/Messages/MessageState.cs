﻿namespace Domain.Messages;

public enum MessageState
{
    New,
    Received,
    Processed
}
