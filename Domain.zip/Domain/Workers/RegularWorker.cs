﻿namespace Domain.Workers;

public class RegularWorker : BaseWorker
{
    public RegularWorker(string name, Guid id) : base(name, id)
    {
    }
}
